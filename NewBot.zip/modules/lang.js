module.exports = class LanguagePicker {
  constructor(langs) {
    if (!langs) throw new Error('UNKNOWN Languages')
    this.langs = langs
  }

  getLang(langCode) {
    return new LangReplacer(this.langs[langCode])
  }

  list() {
    return Object.keys(this.langs)
  }
}

class LangReplacer {
  constructor(lang) {
    if (!lang) throw new Error('UNKNOWN Language')
    this.lang = lang
  }

  get(key, replaces) {
    let result = this.lang[key]
    if (result && replaces) {
      let start = 0
      let end = 0
      while (start >= 0) {
        start = result.indexOf('[')
        end = result.indexOf(']')
        if (end >= 0 && start >= 0) {
          let num = new Number(result.substring(start + 1, end))
          result = result.replace(`[${num}]`, String(replaces[num]))
        }
      }
    }
    return result
  }
}
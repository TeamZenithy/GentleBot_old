# GentleBot
This bot is beta now. / Make your Discord server more Easily, but Powerfully.

# How to run?
1. Simplly change name ``example.config.json`` file to ``config.json`` and edit content of ``config.json`` file
2. rum command ``npm install``
3. run ``node index.js`` or ``node .`` or ``npm start``